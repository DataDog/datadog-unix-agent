A cross-platform uptime for the Python.

See documentation for a full list of supported platforms:
http://packages.python.org/uptime/

Report bugs via email to cairnarvon@gmail.com, or on Github:
https://github.com/Cairnarvon/uptime/issues
